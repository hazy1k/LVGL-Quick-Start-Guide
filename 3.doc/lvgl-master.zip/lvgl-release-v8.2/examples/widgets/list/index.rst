
Simple List 
""""""""""""""""

.. lv_example:: widgets/list/lv_example_list_1
  :language: c


Sorting a List using up and down buttons 
""""""""""""""""

.. lv_example:: widgets/list/lv_example_list_2
  :language: c
