
Simple Line 
""""""""""""""""

.. lv_example:: widgets/line/lv_example_line_1
  :language: c

